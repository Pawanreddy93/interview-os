"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { UploadCloud, FileText, CheckCircle } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';

export default function ResumePage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type === 'application/pdf') {
        setFile(droppedFile);
      } else {
        alert('Please upload a PDF file.');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setAnalyzing(true);
    
    // Simulate analyzing delay for MVP since reading PDF requires a slightly heavier client/server setup
    // And store a dummy parsed text in session for the interview to use
    setTimeout(() => {
      setAnalyzing(false);
      setResult("Resume successfully analyzed! We've extracted 8 key skills and matched them to your profile. You're ready to start your customized interview.");
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('resumeData', "Dummy Extracted Resume Text with skills in React and Node.js");
      }
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Resume Upload</h1>
        <p className="text-slate-400">Upload your latest resume to personalize your interview scenarios.</p>
      </div>

      <Card>
        {!result ? (
          <div className="space-y-6">
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-12 text-center transition-colors \${
                
                  ? 'border-blue-500 bg-blue-500/5' 
                  : 'border-slate-700 bg-slate-900/50 hover:border-slate-500'
              }`}
            >
              <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <UploadCloud className="text-slate-400 w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Drag and drop your resume</h3>
              <p className="text-slate-400 mb-6">PDF format up to 5MB</p>
              
              <input 
                type="file" 
                id="resume-upload" 
                className="hidden" 
                accept=".pdf" 
                onChange={handleFileChange}
              />
              <Button onClick={() => document.getElementById('resume-upload')?.click()}>
                Browse Files
              </Button>
            </div>

            {file && (
              <div className="flex items-center justify-between p-4 bg-slate-800 rounded-xl border border-slate-700">
                <div className="flex items-center gap-3">
                  <FileText className="text-blue-400 w-6 h-6" />
                  <div>
                    <p className="text-white font-medium text-sm">{file.name}</p>
                    <p className="text-slate-400 text-xs">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setFile(null)}>Remove</Button>
              </div>
            )}

            <div className="flex justify-end pt-4">
              <Button 
                onClick={handleAnalyze} 
                disabled={!file || analyzing}
                isLoading={analyzing}
              >
                {analyzing ? 'Analyzing Resume...' : 'Analyze Resume'}
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 space-y-6">
            <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
              <CheckCircle className="text-emerald-500 w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-white">Analysis Complete</h3>
            <p className="text-slate-400 max-w-md mx-auto">{result}</p>
            <div className="pt-6 flex justify-center gap-4">
              <Button variant="outline" onClick={() => {setFile(null); setResult(null);}}>Upload Another</Button>
              <Button onClick={() => router.push('/dashboard/roles')}>Select Role</Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
