"use client";

import React, { useEffect, useState, use } from 'react';
import { useRouter } from 'next/navigation';
import { 
  CheckCircle, ArrowLeft, Loader2, 
  Brain, MessageSquare, Shield, Target 
} from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { generateFeedback } from '@/lib/ai/gemini';

interface FeedbackData {
  technicalScore: number;
  communicationScore: number;
  confidenceScore: number;
  strengths: string[];
  weaknesses: string[];
  summary: string;
}

export default function AnalyticsDetail({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter();
  const { id } = use(params);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<FeedbackData | null>(null);

  useEffect(() => {
    const fetchFeedback = async () => {
      // If we're coming from a newly completed interview
      if (id === 'new') {
        const historyJson = sessionStorage.getItem('lastInterviewHistory');
        if (historyJson) {
          try {
            const history = JSON.parse(historyJson);
            const result = await generateFeedback(history);
            setFeedback(result);
          } catch (e) {
            console.error(e);
          }
        } else {
          // Fallback dummy data if no history found
          setFeedback({
            technicalScore: 8,
            communicationScore: 7,
            confidenceScore: 9,
            strengths: ["Clear problem-solving approach", "Good understanding of fundamentals"],
            weaknesses: ["Could provide more specific examples", "Slight hesitation on advanced topics"],
            summary: "Overall a solid performance. You have a good grasp of the basics but need more practical examples."
          });
        }
      } else {
        // Load existing feedback from DB (simulated here)
        setTimeout(() => {
          setFeedback({
            technicalScore: 8,
            communicationScore: 9,
            confidenceScore: 8,
            strengths: ["Excellent communication", "Clear explanations", "Confident delivery"],
            weaknesses: ["Missed edge cases in system design", "Vague on specific DB optimization techniques"],
            summary: "Strong behavioral and communication skills. Technical skills are good but need sharpening on edge cases."
          });
        }, 1000);
      }
      setLoading(false);
    };

    fetchFeedback();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4">
        <div className="w-16 h-16 relative flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-t-2 border-blue-500 animate-spin"></div>
          <Loader2 className="w-8 h-8 text-blue-500 animate-pulse" />
        </div>
        <h2 className="text-xl font-bold text-white">Analyzing Interview Performance...</h2>
        <p className="text-slate-400">Our AI is generating your personalized feedback.</p>
      </div>
    );
  }

  if (!feedback) return <div>Error loading feedback</div>;

  const totalScore = Math.round((feedback.technicalScore + feedback.communicationScore + feedback.confidenceScore) / 3 * 10);

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <button onClick={() => router.push('/dashboard')} className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">Interview Analysis</h1>
          <p className="text-slate-400">Review your performance and personalized roadmap.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex flex-col items-center justify-center text-center p-8 bg-gradient-to-b from-slate-800 to-slate-900 border-t-4 border-t-blue-500">
          <p className="text-slate-400 font-medium mb-2">Overall Score</p>
          <div className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400 mb-2">
            {totalScore}
          </div>
          <p className="text-sm text-slate-500">out of 100</p>
        </Card>

        <div className="md:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <Card className="flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                <Brain size={20} />
              </div>
              <p className="font-medium text-slate-300">Technical</p>
            </div>
            <div className="text-3xl font-bold text-white mt-auto">{feedback.technicalScore}/10</div>
            <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
              <div className="bg-blue-500 h-full rounded-full" style={{ width: `${feedback.technicalScore * 10}%` }}></div>
            </div>
          </Card>
          
          <Card className="flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                <MessageSquare size={20} />
              </div>
              <p className="font-medium text-slate-300">Communication</p>
            </div>
            <div className="text-3xl font-bold text-white mt-auto">{feedback.communicationScore}/10</div>
            <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
              <div className="bg-purple-500 h-full rounded-full" style={{ width: `${feedback.communicationScore * 10}%` }}></div>
            </div>
          </Card>

          <Card className="flex flex-col">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <Shield size={20} />
              </div>
              <p className="font-medium text-slate-300">Confidence</p>
            </div>
            <div className="text-3xl font-bold text-white mt-auto">{feedback.confidenceScore}/10</div>
            <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${feedback.confidenceScore * 10}%` }}></div>
            </div>
          </Card>
        </div>
      </div>

      <Card className="p-8">
        <h3 className="text-xl font-bold text-white mb-4">Executive Summary</h3>
        <p className="text-slate-300 leading-relaxed text-lg">{feedback.summary}</p>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-t-4 border-t-emerald-500">
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
            <CheckCircle className="text-emerald-500" /> Key Strengths
          </h3>
          <ul className="space-y-4">
            {feedback.strengths.map((s, i) => (
              <li key={i} className="flex items-start gap-3 bg-slate-900/50 p-4 rounded-xl border border-slate-800/50">
                <span className="text-emerald-500 font-bold mt-0.5">•</span>
                <span className="text-slate-300">{s}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="border-t-4 border-t-amber-500">
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
            <Target className="text-amber-500" /> Areas to Improve
          </h3>
          <ul className="space-y-4">
            {feedback.weaknesses.map((w, i) => (
              <li key={i} className="flex items-start gap-3 bg-slate-900/50 p-4 rounded-xl border border-slate-800/50">
                <span className="text-amber-500 font-bold mt-0.5">•</span>
                <span className="text-slate-300">{w}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="flex justify-center pt-8">
        <Button size="lg" onClick={() => router.push('/dashboard/roles')}>
          Practice Again
        </Button>
      </div>
    </div>
  );
}
