"use client";

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { Play, Clock, Award, TrendingUp, AlertTriangle } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';

export default function Dashboard() {
  const { user } = useAuth();
  
  // Dummy data for MVP layout
  const stats = {
    totalInterviews: 12,
    avgScore: 84,
    improvement: '+5%',
  };

  const recentInterviews = [
    { id: 1, role: 'Software Engineer', date: '2 days ago', score: 88, status: 'Completed' },
    { id: 2, role: 'Technical Support', date: '1 week ago', score: 76, status: 'Completed' },
    { id: 3, role: 'QA Tester', date: '2 weeks ago', score: 82, status: 'Completed' },
  ];

  const resumeSkills = ['React', 'TypeScript', 'Node.js', 'Firebase', 'Troubleshooting', 'Customer Service'];
  const weakSkills = ['System Design', 'Performance Optimization', 'Network Protocols'];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">
          Welcome back, {user?.displayName || user?.email?.split('@')[0]}! 👋
        </h1>
        <p className="text-slate-400">Here&apos;s your interview preparation progress.</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
            <Play className="text-blue-400 w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">Total Interviews</p>
            <p className="text-2xl font-bold text-white">{stats.totalInterviews}</p>
          </div>
        </Card>
        
        <Card className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
            <Award className="text-emerald-400 w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">Average Score</p>
            <div className="flex items-baseline gap-2">
              <p className="text-2xl font-bold text-white">{stats.avgScore}/100</p>
              <span className="text-xs text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full">
                {stats.improvement}
              </span>
            </div>
          </div>
        </Card>
        
        <Card className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-400 font-medium mb-1">Next Step</p>
            <p className="text-lg font-bold text-white mb-3">Practice System Design</p>
            <Link href="/dashboard/roles">
              <Button size="sm" className="gap-2">
                Start Interview <Play size={14} fill="currentColor" />
              </Button>
            </Link>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Column */}
        <div className="lg:col-span-2 space-y-8">
          {/* Recent Interviews */}
          <Card>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white">Recent Interviews</h2>
              <Link href="/dashboard/analytics" className="text-sm text-blue-400 hover:text-blue-300 font-medium">
                View all
              </Link>
            </div>
            
            <div className="space-y-4">
              {recentInterviews.map((interview) => (
                <div key={interview.id} className="flex items-center justify-between p-4 rounded-xl bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center border border-slate-700">
                      <Clock className="text-slate-400 w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-white">{interview.role}</p>
                      <p className="text-sm text-slate-400">{interview.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-bold text-emerald-400">{interview.score}/100</p>
                      <p className="text-xs text-slate-500">{interview.status}</p>
                    </div>
                    <Link href={`/dashboard/analytics/${interview.id}`}>
                      <Button variant="ghost" size="sm">Review</Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Side Column */}
        <div className="space-y-8">
          {/* Resume Summary */}
          <Card>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white">Resume Analysis</h2>
              <Link href="/dashboard/resume" className="text-sm text-blue-400 hover:text-blue-300 font-medium">
                Update
              </Link>
            </div>
            
            <div className="space-y-6">
              <div>
                <p className="text-sm text-slate-400 font-medium flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Strong Skills
                </p>
                <div className="flex flex-wrap gap-2">
                  {resumeSkills.map((skill) => (
                    <span key={skill} className="text-xs font-medium px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              
              <div>
                <p className="text-sm text-slate-400 font-medium flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Areas to Improve
                </p>
                <div className="flex flex-wrap gap-2">
                  {weakSkills.map((skill) => (
                    <span key={skill} className="text-xs font-medium px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
