"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Mic, MicOff, Send, PhoneOff, Loader2 } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { getGeminiChatSession } from '@/lib/ai/gemini';

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
}

function InterviewContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const roleParam = searchParams.get('role') || 'Software Engineer';
  const jdParam = searchParams.get('jd') || ''; // retrieve jd parameter
  
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'ai', content: "Hello! Welcome to the interview. To start, could you please introduce yourself and tell me a bit about your background?" }
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Speech recognition and synthesis state
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const chatSessionRef = useRef<any>(null);
  const synthesisRef = useRef<SpeechSynthesis | null>(null);
  const silenceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const transcriptRef = useRef('');

  const speakText = (text: string) => {
    if (!synthesisRef.current) return;
    synthesisRef.current.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    // Optional: tweak voice settings
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    synthesisRef.current.speak(utterance);
  };

  useEffect(() => {
    // Initialize Gemini chat, pass JD param to configure the prompt
    let fullJd = '';
    let resumeText = '';
    if (typeof window !== 'undefined') {
      if (jdParam === 'true') fullJd = sessionStorage.getItem('jdForInterview') || '';
      resumeText = sessionStorage.getItem('resumeData') || '';
    }
    chatSessionRef.current = getGeminiChatSession(roleParam, fullJd, resumeText);
    
    // Initialize Speech Recognition
    if (typeof window !== 'undefined') {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        recognitionRef.current.onresult = (event: any) => {
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript + ' ';
            }
          }

          if (finalTranscript.trim()) {
            transcriptRef.current += ' ' + finalTranscript.trim();
            setInputText(transcriptRef.current);

            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
            }

            silenceTimerRef.current = setTimeout(() => {
              recognitionRef.current?.stop();
              setIsRecording(false);
            }, 2000);
          }
        };

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        recognitionRef.current.onerror = (event: any) => {
          console.error("Speech recognition error", event.error);
          setIsRecording(false);
        };
        
        recognitionRef.current.onend = () => {
          setIsRecording(false);
        };
      }

      synthesisRef.current = window.speechSynthesis;
    }

    // Speak initial message
    speakText(messages[0].content);

    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (synthesisRef.current) synthesisRef.current.cancel();
    };
  }, [roleParam]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isAiTyping]);

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      if (synthesisRef.current) synthesisRef.current.cancel(); // Stop AI speaking if user starts talking
      setInputText('');
      transcriptRef.current = '';
      try {
        recognitionRef.current?.start();
        setIsRecording(true);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || isAiTyping) return;

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    }

    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: inputText.trim() };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsAiTyping(true);

    try {
      // If using dummy key, simulate response
      if (process.env.NEXT_PUBLIC_GEMINI_API_KEY === "dummy-key" || !process.env.NEXT_PUBLIC_GEMINI_API_KEY) {
        setTimeout(() => {
          const aiText = "Thank you for sharing that. Can you explain a complex technical problem you solved recently and how you approached it?";
          const aiMessage: Message = { id: Date.now().toString(), role: 'ai', content: aiText };
          setMessages(prev => [...prev, aiMessage]);
          setIsAiTyping(false);
          speakText(aiText);
        }, 1500);
      } else {
        const result = await chatSessionRef.current.sendMessage(userMessage.content);
        const aiText = result.response.text();
        const aiMessage: Message = { id: Date.now().toString(), role: 'ai', content: aiText };
        setMessages(prev => [...prev, aiMessage]);
        setIsAiTyping(false);
        speakText(aiText);
      }
    } catch (e) {
      console.error(e);
      const aiMessage: Message = { id: Date.now().toString(), role: 'ai', content: "I'm sorry, I'm having trouble connecting to my servers right now. Could you repeat that?" };
      setMessages(prev => [...prev, aiMessage]);
      setIsAiTyping(false);
      speakText(aiMessage.content);
    }
  };

  const handleEndInterview = () => {
    if (synthesisRef.current) synthesisRef.current.cancel();
    if (recognitionRef.current) recognitionRef.current.stop();
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    
    // Save messages to session storage to pass to analytics page in MVP
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('lastInterviewHistory', JSON.stringify(messages));
    }
    
    router.push('/dashboard/analytics/new');
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <span className="relative flex h-3 w-3 mr-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            Interview in Progress
          </h1>
          <p className="text-slate-400">Role: {roleParam.replace('-', ' ')}</p>
        </div>
        <Button variant="danger" onClick={handleEndInterview} className="gap-2">
          <PhoneOff size={18} /> End Interview
        </Button>
      </div>

      <Card className="flex-1 flex flex-col mb-6 overflow-hidden p-0 border-slate-700 bg-slate-900/60">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl p-4 ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-tl-none'
              }`}>
                {msg.role === 'ai' && (
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded bg-blue-500/20 flex items-center justify-center border border-blue-500/30 text-xs font-bold text-blue-400">
                      AI
                    </div>
                    <span className="text-xs text-slate-400 font-medium">Interviewer</span>
                  </div>
                )}
                <p className="leading-relaxed">{msg.content}</p>
              </div>
            </div>
          ))}
          
          {isAiTyping && (
            <div className="flex justify-start">
              <div className="bg-slate-800 border border-slate-700 rounded-2xl rounded-tl-none p-4 flex items-center gap-2">
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <div className="flex items-end gap-3">
            <button
              onClick={toggleRecording}
              className={`p-4 rounded-xl flex-shrink-0 transition-all ${
                isRecording 
                  ? 'bg-red-500/10 text-red-500 border border-red-500/30 hover:bg-red-500/20' 
                  : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700 hover:text-white'
              }`}
            >
              {isRecording ? <Loader2 className="w-6 h-6 animate-spin" /> : <Mic className="w-6 h-6" />}
            </button>
            
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={isRecording ? "Listening..." : "Type your answer or use the microphone..."}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-4 text-white placeholder-slate-500 focus:ring-blue-500 focus:border-blue-500 resize-none max-h-32 min-h-[56px]"
              rows={Math.min(4, inputText.split('\n').length)}
            />
            
            <Button 
              onClick={handleSendMessage} 
              disabled={!inputText.trim() || isAiTyping}
              className="p-4 h-auto rounded-xl flex-shrink-0"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
          {isRecording && (
            <p className="text-xs text-red-400 mt-2 text-center animate-pulse">
              Recording your answer... Click microphone to stop.
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}

export default function InterviewSession() {
  return (
    <React.Suspense fallback={<div className="text-white text-center p-8">Loading interview setup...</div>}>
      <InterviewContent />
    </React.Suspense>
  );
}
