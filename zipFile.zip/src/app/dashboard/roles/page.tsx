"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Terminal, Headphones, Bug, ArrowRight } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';

export default function RolesPage() {
  const router = useRouter();
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [jd, setJd] = useState('');

  const roles = [
    {
      id: 'software-engineer',
      title: 'Software Engineer',
      icon: Terminal,
      color: 'blue',
      description: 'Practice coding algorithms, system design, debugging, and behavioral questions.'
    },
    {
      id: 'technical-support',
      title: 'Technical Support',
      icon: Headphones,
      color: 'emerald',
      description: 'Troubleshoot networks, handle angry customers, and navigate ticketing systems.'
    },
    {
      id: 'qa-tester',
      title: 'QA Tester',
      icon: Bug,
      color: 'purple',
      description: 'Identify bugs, write test cases, and explain automation and regression testing.'
    }
  ];

  const handleStartInterview = () => {
    if (!selectedRole) return;
    
    // Pass JD and role via URL params or session storage (for large text)
    const params = new URLSearchParams();
    params.set('role', selectedRole);
    if (jd) {
      if (typeof window !== 'undefined') {
         sessionStorage.setItem('jdForInterview', jd);
      }
      params.set('jd', 'true');
    }
    
    router.push(`/dashboard/interview?${params.toString()}`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Select a Role</h1>
        <p className="text-slate-400">Choose the IT role you are preparing for.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {roles.map((role) => {
          const Icon = role.icon;
          const isSelected = selectedRole === role.id;
          
          return (
            <div 
              key={role.id}
              onClick={() => setSelectedRole(role.id)}
              className={`rounded-2xl p-6 cursor-pointer transition-all duration-300 border-2 ${
                isSelected 
                  ? 'bg-slate-800/80 border-blue-500 shadow-[0_0_20px_rgba(37,99,235,0.2)]' 
                  : 'bg-slate-900 border-slate-800 hover:border-slate-600'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl mb-4 flex items-center justify-center border ${
                isSelected 
                  ? 'bg-blue-500/20 border-blue-500/30' 
                  : 'bg-slate-800 border-slate-700'
              }`}>
                <Icon className={isSelected ? 'text-blue-400' : 'text-slate-400'} size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{role.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{role.description}</p>
            </div>
          );
        })}
      </div>

      {selectedRole && (
        <Card className="mt-8 animate-in slide-in-from-bottom-4 duration-500">
          <h3 className="text-xl font-bold text-white mb-4">Job Description (Optional)</h3>
          <p className="text-slate-400 mb-4 text-sm">
            Paste the job description here to let the AI tailor the interview questions precisely to the company&apos;s requirements.
          </p>
          <textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            placeholder="Paste job description here..."
            className="w-full h-40 bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-white placeholder-slate-500 focus:ring-blue-500 focus:border-blue-500 transition-colors resize-none"
          />
          <div className="mt-6 flex justify-end">
            <Button size="lg" onClick={handleStartInterview} className="group">
              Start Simulation
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
