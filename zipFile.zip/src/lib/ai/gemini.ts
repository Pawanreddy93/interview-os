import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY || "dummy-key";
const genAI = new GoogleGenerativeAI(apiKey);

export const getGeminiChatSession = (role: string, jobDescription?: string, resumeText?: string) => {
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  let promptContext = `You are a professional IT interviewer. Your current role to interview the candidate for is: ${role}.`;
  
  if (jobDescription && jobDescription.trim() !== '') {
    promptContext += `
Here is the job description you must base some of your questions on:
"""
${jobDescription}
"""`;
  }
  
  if (resumeText && resumeText.trim() !== '') {
    promptContext += `\nHere is the candidate's resume summary. Personalize your questions based on their experience:\n"""\n\${resumeText}\n"""`;
  }

  const systemPrompt = `${promptContext}
You must simulate a realistic interview. Ask ONE question at a time.
Keep your responses conversational, professional, and concise. 
Start by greeting the candidate and asking them to introduce themselves.
If the candidate's answer is weak, challenge them naturally or provide gentle guidance.
Include a mix of behavioral and technical questions specific to the ${role} role.
Ask follow-up questions based on the candidate previous answer.
Always continue to the next relevant interview question.
Never get stuck repeating the introduction question.`;

  return model.startChat({
    history: [
      {
        role: "user",
        parts: [{ text: `System Instructions:
${systemPrompt}

Start the interview.` }],
      },
      {
        role: "model",
        parts: [{ text: "Hello! Welcome to the interview. To start, could you please introduce yourself and tell me a bit about your background?" }],
      }
    ],
  });
};

export const generateFeedback = async (chatHistory: { role: string, content: string }[]) => {
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  
  const historyText = chatHistory.map(msg => `\${msg.role === 'user' ? 'Candidate' : 'Interviewer'}: \${msg.content}`).join('\n');
  
  const prompt = `Review the following interview transcript and provide a JSON response with the following keys:
  - "technicalScore": number (out of 10)
  - "communicationScore": number (out of 10)
  - "confidenceScore": number (out of 10)
  - "problemSolvingScore": number (out of 10)
  - "strengths": array of 3 strings
  - "weaknesses": array of 3 strings
  - "learningRoadmap": array of 3 actionable steps to improve
  - "summary": string (overall feedback)
  
  Interview Transcript:
  \${historyText}
  `;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    const jsonStr = text.replace(/```json|```/g, '').trim();
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error("Error generating feedback", e);
    return {
      technicalScore: 7,
      communicationScore: 8,
      confidenceScore: 7,
      problemSolvingScore: 7,
      strengths: ["Clear communication", "Good foundational knowledge", "Professional tone"],
      weaknesses: ["Lacked deep technical details", "Hesitant on complex scenarios", "Rambled slightly on behavioral question"],
      learningRoadmap: ["Review system design patterns", "Practice edge case identification", "Mock interview on behavioral questions"],
      summary: "You did fairly well, but there is room to improve on providing deeper technical context."
    };
  }
};
